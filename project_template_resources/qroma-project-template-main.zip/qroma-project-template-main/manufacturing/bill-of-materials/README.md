# Bill of Materials

Ultimately, this list should emerge from "compiling" all of the assets associated with the parts inside. Until then, we recommend automating what you can, but keeping track of the rest of things by hand, maybe in a CSV file.