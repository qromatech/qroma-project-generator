# Construction

The goal of this directory is to keep all of the documentation and artifacts associated with the physical assembly and construction of the product in one place and "compilable".
