# Running a Project

* Install `qroma` command line app
* Run `qroma new --dev-board-platforms arduino :my-qroma-project`
* Run `qroma build`
* Upload built project to your ESP32 device
  * Test with monitor. You should see output like so...
  * TBD
* From command line, navigate to Python app directory (e.g. `my-qroma-project/apps/py-qroma-io`)
  * These steps require Python 3.11 and poetry
  * Run `` 