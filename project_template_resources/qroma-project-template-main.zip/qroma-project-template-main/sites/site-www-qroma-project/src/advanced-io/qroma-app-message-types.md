---
title: Qroma Comm Types
---

# Qroma App Types

Introspection stuff for declared types goes here...
  
import { MyProjectCommand, MyProjectResponse } from "../qroma-proto/my-project-messages";
import { QromaAppViewMessageTypesComponent } from "../react-qroma-lib";


<QromaAppViewMessageTypesComponent
  messages={MyProjectCommand}
  />