---
displayed_sidebar: getStartedSidebar
---

This is the index for Get Started