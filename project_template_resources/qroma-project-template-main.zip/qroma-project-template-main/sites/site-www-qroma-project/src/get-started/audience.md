---
title: Audience
---

# qroma-boards Audience

What readers is this project/website for?
* What should they know?
* Tech level? 
* What skills are required?
