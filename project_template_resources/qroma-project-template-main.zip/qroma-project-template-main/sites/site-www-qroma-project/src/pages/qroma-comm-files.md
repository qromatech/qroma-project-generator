---
title: Qroma Comm Dev
---

# Qroma Comm File Explorer

import BrowserOnly from '@docusaurus/BrowserOnly';
import { QromaCommFileExplorerComponent } from "../react-qroma-lib";


<BrowserOnly>
{() =>
  <QromaCommFileExplorerComponent
    />
}
</BrowserOnly>