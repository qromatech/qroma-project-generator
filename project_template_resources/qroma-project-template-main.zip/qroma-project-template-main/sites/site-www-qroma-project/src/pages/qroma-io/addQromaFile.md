---
title: Add Qroma File
---

# Qroma Add Qroma File MD

import BrowserOnly from '@docusaurus/BrowserOnly';
import { QromaIoAddQromaFileComponent } from "../../react-qroma-lib";

<BrowserOnly>
{() =>
  <QromaIoAddQromaFileComponent
    />
}
</BrowserOnly>