---
title: Send Qroma Dir
---

# Qroma Show Dir MD

import BrowserOnly from '@docusaurus/BrowserOnly';
import { QromaIoShowQromaDirComponent } from "../../react-qroma-lib";

<BrowserOnly>
{() =>
  <QromaIoShowQromaDirComponent
    />
}
</BrowserOnly>