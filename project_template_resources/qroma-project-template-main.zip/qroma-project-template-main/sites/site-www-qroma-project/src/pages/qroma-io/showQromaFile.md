---
title: Show Qroma File
---

# Qroma Show File MD

import BrowserOnly from '@docusaurus/BrowserOnly';
import { QromaIoShowQromaFileComponent } from "../../react-qroma-lib";

<BrowserOnly>
{() =>
  <QromaIoShowQromaFileComponent
    />
}
</BrowserOnly>