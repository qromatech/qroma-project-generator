---
title: Send Qroma Comm Message
---

# Qroma Send Qroma Comm Message MD

import BrowserOnly from '@docusaurus/BrowserOnly';
import { QromaIoSendQromaCommMessageComponent } from "../../react-qroma-lib";

<BrowserOnly>
{() =>
  <QromaIoSendQromaCommMessageComponent
    />
}
</BrowserOnly>