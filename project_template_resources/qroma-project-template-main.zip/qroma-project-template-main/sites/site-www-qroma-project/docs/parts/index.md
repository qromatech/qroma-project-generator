
# Sample parts list

Put the parts someone would require here

* Part 1
* Part 2
* Part...
* Part N