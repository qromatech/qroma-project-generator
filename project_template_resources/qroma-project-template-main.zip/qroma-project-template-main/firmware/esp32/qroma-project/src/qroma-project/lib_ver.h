
#ifndef LIB_VER_QROMA_FIRMWARE_H
#define LIB_VER_QROMA_FIRMWARE_H

#define LIB_VER             "0.0.1"
#define QROMA_PROJECT_NAME  "{{ qroma_project.project_id }}"



#endif
