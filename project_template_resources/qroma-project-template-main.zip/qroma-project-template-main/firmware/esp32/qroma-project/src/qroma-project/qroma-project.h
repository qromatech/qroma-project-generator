#ifndef QROMA_PROJECT_H
#define QROMA_PROJECT_H

#include <Arduino.h>
#include "qroma-commands.h"


void qromaProjectSetup();

void qromaProjectLoop();

#endif