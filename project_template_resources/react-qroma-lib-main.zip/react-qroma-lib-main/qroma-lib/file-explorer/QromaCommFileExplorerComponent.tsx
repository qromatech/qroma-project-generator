import React from "react";
import { QromaCommFileExplorerUiComponent } from "./QromaCommFileExplorerUiComponent";
// import { QromaCommFileSystemApi } from "./QromaCommFileSystemApi";


export const QromaCommFileExplorerComponent = () => {

  // const qromaCommFileSystemApi = QromaCommFileSystemApi();

  return (
    <QromaCommFileExplorerUiComponent
      // qromaCommFileSystemApi={qromaCommFileSystemApi}
      />
  )
}
