import { createContext } from "react";
import { IQromaPageApp } from "./QromaPageApp";


export const QromaPageAppContext = createContext<IQromaPageApp>({

} as IQromaPageApp);
