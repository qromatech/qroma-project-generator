import React from "react"
import { QromaIoShowQromaFileUiComponent } from "./QromaIoShowQromaFileUiComponent";


interface IQromaIoShowQromaFileComponentProps { }

export const QromaIoShowQromaFileComponent = (
  props: IQromaIoShowQromaFileComponentProps
) => {

  return (
    <QromaIoShowQromaFileUiComponent
      />
  )
}
